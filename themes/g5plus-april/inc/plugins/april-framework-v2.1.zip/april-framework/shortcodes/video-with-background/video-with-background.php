<?php
/**
 * The template for displaying video-with-background.php
 *
 * @package WordPress
 * @subpackage april
 * @since april 1.0
 */
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}
class WPBakeryShortCode_GSF_Video_With_Background extends G5P_ShortCode_Base {
}